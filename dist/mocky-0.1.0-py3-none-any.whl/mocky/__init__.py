def do():
    return True

def dontdo():
    return False

def check():
    return "I'm a mocky!"
